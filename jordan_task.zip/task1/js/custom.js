//$postModule = angular.module('tApp', []);
//$postModule.controller('userController',function($scope, $http){
	
// define application
angular.module("tApp",  ["chart.js", "ui.bootstrap"])
.controller("userController", function($scope,$http){ 
	 
    $scope.users = [{
                        id:'0',
                        name:'Dog',
                       action :'can not fly'
                    },
					{
                        id:'1',
                        name:'Cat',
                        action:'can not fly'
                    },
					{
                        id:'2',
                        name:'parrot',
                        action:'can  fly'
                    }
					];
    $scope.tempUserData = {};
  
    // function to add user data
    $scope.addUser = function(tempUserData){
       $scope.users.push({
                        id:'',
                        action:tempUserData.action,
                        name:tempUserData.name 
                    });
    };
      
    
    // function to delete user data from the database
    $scope.deleteUser = function(index){
        $scope.users.splice(index,1);
    };
	
	 
	 
	
	
    // function to display success message
    $scope.messageSuccess = function(msg){
        $('.alert-success > p').html(msg);
        $('.alert-success').show();
        $('.alert-success').delay(5000).slideUp(function(){
            $('.alert-success > p').html('');
        });
    };
    
    // function to display error message
    $scope.messageError = function(msg){
        $('.alert-danger > p').html(msg);
        $('.alert-danger').show();
        $('.alert-danger').delay(5000).slideUp(function(){
            $('.alert-danger > p').html('');
        });
    };
});


 