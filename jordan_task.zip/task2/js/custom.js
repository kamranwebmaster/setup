//$postModule = angular.module('tApp', []);
//$postModule.controller('userController',function($scope, $http){
	
// define application
angular.module("tApp",  ["chart.js", "ui.bootstrap"])
.controller("userController", function($scope,$http){ 
	 
	 
           $scope.importedcsv = "";
	 	 $('#import_csv').change(function (e) {
               $scope.importedcsv = e.target.files[0].name;
			     $scope.parsecsv();
               $scope.$digest();
           });
		   
		   $('input[type="file"]').change(function (e) {
              $scope.importedcsv = e.target.files[0].name;
			  $scope.parsecsv();
              $scope.$digest();
           });

           $('#import_csv').change(function (e) {
               $scope.importedcsv = e.target.files[0].name;
			     $scope.parsecsv();
               $scope.$digest();
           });
		   
		    $scope.choosecsvfile = function () {
               $scope.importedcsv = e.target.files[0].name;
			     $scope.parsecsv();
           }

           function choosecsvfile(e) {
               alert(e);
           }
		   
           $scope.parsing = true;
           $scope.parsecsv = function () {
              
              $scope.parsing = true;
              $scope.mapping = true;

              var myfile = $("#import_csv")[0].files[0];

              Papa.parse(myfile, {
                 header: false,
                 dynamicTyping: true,
                 complete: function(results) {
                   //  $scope.users = results;
					// console.log($scope.users)
					 
								 
					var table = "<table id='testTable'   class='table table-striped'";
					var data = results.data;
					 
					for(i=0;i<data.length;i++){
						table+= "<tr>";
						var row = data[i];
						var cells = row.join(",").split(",");
						 
						for(j=0;j<cells.length;j++){
							table+= "<td>";
							table+= cells[j];
							table+= "</th>";
						}
						table+= "</tr>";
					}
					table+= "</table>";
					$("#parsed_csv_list").html(table);
	
                  ;//   $scope.validateusers();
                    //$scope.getTableFields();
                 }
              });

              $scope.parsing = false;
           };
 
	 
});
 

 